export default function createTextMaskInputElement(a: any): any
